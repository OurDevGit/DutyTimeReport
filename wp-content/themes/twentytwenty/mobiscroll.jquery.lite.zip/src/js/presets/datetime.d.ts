import { DatetimeBase } from './datetimebase';

export class DateTime extends DatetimeBase { }
